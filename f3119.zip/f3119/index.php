<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>главная</title>
	<link rel="stylesheet"  href="css/style.css">
</head>
<body>
	<div class="logo"><p>company logo and slogan</p> </div>
	<header><p>header</p></header>
	<nav>
		<a href="#">link1</a>
		<a href="#">link2</a>
		<a href="#">link3</a>
		<a href="#">link4</a>
	</nav>
	<main>
		<div class="content"> <p>about</p> </div>
		<div class="content2">
			<div><p>quick links</p></div>
			<div><p>quick links</p></div>
		</div>
	</main>
	<footer><p>site plan and copyright info</p></footer>
	
	
</body>
</html>




